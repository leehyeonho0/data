
# coding: utf-8

# In[ ]:


def square(x):
    return x ** 2

for N in range(1,4):
    print(N, '의 제곱은', square(N))

