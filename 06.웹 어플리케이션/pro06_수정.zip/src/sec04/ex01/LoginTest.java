package sec04.ex01;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 실습 예제 : 서블릿으로 로그인 요청 시 관리자 화면 나타내기
 */
@WebServlet("/loginTest")
public class LoginTest extends HttpServlet {
	
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init 메소드");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
request.setCharacterEncoding("UTF-8");
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("user_id");
		String pw = request.getParameter("user_pw");
				
		if(id != null &&(id.length() != 0)) {
			// 이중 if 문을 사용해 ID가 admin이면 관리자 창을 보여줌
			if(id.equals("admin")) {
				out.print("<html>");
				out.print("<body>");
				out.print("<font size='12'>관리자로 로그인 하셨습니다!!</>");
				out.print("<br>");
				out.print("<input type='button' value='회원정보 수정하기'>");
				out.print("<input type='button' value='회원정보 삭제하기'>");
				out.print("</body>");
				out.print("<html>");
			}
			else {// 관리자가 아닌 일반 사용자일 경우 로그인 성공 메시지를 보여줌
				out.print("<html>");
				out.print("<body>");
				out.print(id + " 님!! 로그인 하셨습니다.");
				out.print("</body>");
				out.print("<html>");
			}
		}
		else {
			out.print("<html>");
			out.print("<body>");
			out.print("ID와 비밀번호를 입력하세요!!");
			out.print("<br>");	
			out.print("<a href='http://localhost:8090/pro06/test01/login.html'>로그인 창으로 이동 </a>");
			out.print("</body>");
			out.print("<html>");
		}
		
		
	}

}
