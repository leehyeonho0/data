package sec01.ex01;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MemberController
 */
/* @WebServlet("/mem.do") */
/* @WebServlet("*.do") */
@WebServlet("/member/*")
public class MemberController extends HttpServlet {
	
	MemberDAO memberDAO;
	
	public void init(ServletConfig config) throws ServletException {
		memberDAO = new MemberDAO(); // MemberDAO 생성
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}
	
	protected void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String action = request.getPathInfo();
		System.out.println("action == "+ action);
		
		RequestDispatcher dispatch = null;
		
		if(action.equals("/delMember.do")) { // 회원 삭제
			
			String id = request.getParameter("id");
			
			MemberVO vo = new MemberVO();
			vo.setId(id);
			
			memberDAO.delMember(vo);
			
			// 컨트롤러에서 표시하고자 하는 JSP로 포워딩 한다.
			 dispatch = 
					request.getRequestDispatcher("/member/listMembers.do");
		}else if(action.equals("/addMember.do")){ 
			// 회원 가입
			String id = request.getParameter("id");
			String pwd = request.getParameter("pwd");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			
			MemberVO vo = new MemberVO();
			vo.setId(id);
			vo.setPwd(pwd);
			vo.setName(name);
			vo.setEmail(email);
			
			memberDAO.addMember(vo);
			
			// 컨트롤러에서 표시하고자 하는 JSP로 포워딩 한다.
			 dispatch = 
					request.getRequestDispatcher("/member/listMembers.do");
			 
		}else if(action.equals("/modMemberForm.do")){ // Update
			// 회원 수정 폼
			String id = request.getParameter("id");
			
			MemberVO memInfo = memberDAO.findMember(id);
			request.setAttribute("memInfo", memInfo);
			
			
			// 컨트롤러에서 표시하고자 하는 JSP로 포워딩 한다.
			 dispatch = 
					request.getRequestDispatcher("/test01/modMemberForm.jsp");
			 
		}else if(action.equals("/modMember.do")){ 
			// 회원 수정
			String id = request.getParameter("id");
			String pwd = request.getParameter("pwd");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			
			MemberVO vo = new MemberVO();
			vo.setId(id);
			vo.setPwd(pwd);
			vo.setName(name);
			vo.setEmail(email);
			
			memberDAO.modMember(vo);
			
			// 컨트롤러에서 표시하고자 하는 JSP로 포워딩 한다.
			 dispatch = 
					request.getRequestDispatcher("/member/listMembers.do");
			 
		}else {
			// 회원 정보 조회
			List membersList = memberDAO.listMembers();
			
			// 조회한 회원 정보를 request에 바인딩 한다.
			request.setAttribute("membersList", membersList);
			
			// 컨트롤러에서 표시하고자 하는 JSP로 포워딩 한다.
			dispatch = 
					request.getRequestDispatcher("/test01/listMembers.jsp");
		}
		dispatch.forward(request, response);
	}

}
